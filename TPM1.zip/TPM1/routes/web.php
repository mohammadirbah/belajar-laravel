<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/data', function () {
    $programs = ['php', 'java', 'c', 'javascript', 'dart'];
    return view('programs', ['programs' => $programs]);
});
